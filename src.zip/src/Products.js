import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { UserContext } from "./UserContext";


const Products = () => {
 // const { id } = useParams();
  const [data, setData] = useState([]);
  const user=useContext(UserContext);
    const Attr = ["ID", "Name", "Price", "Action"];
  const [itemSelected, setitemSelected] = useState({
    id: "",
    name: "",
    price: "",
    
  }); 
  const [items, setItems] = useState([]) ;
  useEffect(() => {
    axios
      .get("http://localhost:3006/products")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
    const handleUpdate = (id) => {    
  //    e.preventDefault();         
          axios
            .get(`http://localhost:3006/products/${id}`)
            .then((res) => {               
                setitemSelected({
          id: res.data.id,
          name: res.data.name,
          price: res.data.price
        });
        if(itemSelected.name!=="")
          { 
        setItems([...items,itemSelected]);
        alert("Item Added: "+ itemSelected.name)  
          }
        })    
        .catch((err) => console.log(err));    
        
      };    
    const handleDelete = (id) => {
  //alert(id);
  setItems({
    items: items.filter((item) => item.id !== id),
  }); 
};
  return (
    <div><h1>Welcome {user.username}</h1>
    <section>
      <div>
        <h2>Add Products</h2> 
        <Link to="/ViewCart" state={{cartItems:items}}>
          <button className="btn btn-dark">View Cart</button>
        </Link>
    </div>       
        <table border="1">
            <thead>
              <tr>
          {Attr.map((att) => (
            <td key={att}>{att}</td>
          ))}
          </tr>
          </thead>
          <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.price}</td>
              <td>
              <button className="btn btn-dark" onClick={() => handleUpdate(item.id)}>Add to Cart</button>
              </td>
              
            </tr>
          ))}
        </tbody>
      </table>
<br></br>
<h1>Items in Cart</h1>
      <table border="1">
            <thead>
              <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Price</td>
          </tr>
          </thead>
          <tbody>
          {items.map((cartitem, index) => (
            <tr key={index}>
              <td>{cartitem.id}</td>
              <td>{cartitem.name}</td>
              <td>{cartitem.price}</td>
              <td>
              <button className="btn btn-dark" onClick={() => handleDelete(cartitem.id)}>Remove From Cart</button>
              </td>
              
            </tr>
          ))}
        </tbody>
      </table>
      
    </section></div>
  );
};

export default Products;
