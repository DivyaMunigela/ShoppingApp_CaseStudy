import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";


const Products = () => {

  const [data, setData] = useState([]);

  const Attr = ["ID", "Name", "Price", "Actions"];
  const [itemSelected, setitemSelected] = useState({
    id: "",
    name: "",
    price: "",
    
  }); 
    const [items, setItems] = useState([]) 
  

  useEffect(() => {
    axios
      .get("http://localhost:3006/products")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
    const handleUpdate = (id) => {
        alert("From Handle")
              
          axios
            .get(`http://localhost:3006/products/${id}`)
            .then((res) => {
                alert(res.data.name);
                
                setitemSelected({
          id: res.data.id,
          name: res.data.name,
          price: res.data.price
        });
        setItems([...items,itemSelected]);
               alert(items.length);
               
               //window.location.reload();

            })
            .catch((err) => console.log(err));
        };
      
    const handleDelete = (id) => {
    
    
      axios
        .get(`http://localhost:3006/products/${id}`)
        .then((res) => {
          // log the id here
          // window.location.reload();
          console.log(res);
        })
        .catch((err) => console.log(err));
    
    console.log(id);
  };
  return (
    <section>
      <div>
        <h1>List Of Products</h1> 
        <Link to={{ pathname:'/ViewCart', state:{cartItems:items}}}>
          <button className="btn btn-dark">View Cart</button>
        </Link>
        {/* <button className="btn btn-dark">
            <Link to="/create">
            New
            </Link>
        </button> */}
      </div>
      
        <table border="1">
            <thead>
              <tr>
          {Attr.map((att) => (
            <td key={att}>{att}</td>
          ))}
          </tr>
          </thead>
          <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.price}</td>
              <td>
              <button className="btn btn-dark" onClick={() => handleUpdate(item.id)}>Add to Cart</button>
              </td>
              <td>
              <button className="btn btn-dark" onClick={() => handleDelete(item.id)}>Remove From Cart</button>
              </td>
              
            </tr>
          ))}
        </tbody>
      </table>
      
    </section>
  );
};

export default Products;
