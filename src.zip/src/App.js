import './App.css';
import Confirmation from './Components/Confirmation';
import SignUp from './Components/SignUp';
import ViewCart from './Components/ViewCart';
import LoginScreen from './LoginScreen';
import Products from './Products';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      <Routes>
        <Route path="/" element={<LoginScreen />} >
        </Route>
        <Route path="/products" element={<Products />} >
        </Route>
        <Route path="/ViewCart" element={<ViewCart />}  >
        </Route> 
        <Route path="/SignUp" element={<SignUp />} >
        </Route> 
        <Route path="/Confirmation" element={<Confirmation />} >
        </Route> 

      </Routes>
      
      </header>
    </div>
  );
}

export default App;
