import './App.css';
import ViewCart from './Components/ViewCart';
import LoginForm from './Login';
import LoginScreen from './LoginScreen';
import Products from './Products';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      <Routes>
        <Route path="/" element={<LoginScreen />} >
        </Route>
        <Route path="/products" element={<Products />} >
        </Route>
        <Route path="/ViewCart" element={<ViewCart />} >
        </Route> 
      </Routes>
      
      </header>
    </div>
  );
}

export default App;
