import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import React from 'react'


const LoginScreen = () => {
  const prouctsPage = useNavigate();
  /* const [data, setData] = useState([]);

  const Attr = ["username","password", "email"];
  const prouctsPage = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:3005/users")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []); */
  
function Validate()
{
  //  alert("From Validate"); // In Progress
    prouctsPage("/products");
}  
return (
    <section>
      <div>
        <h1>Welcome to TMart, Login to continue shopping</h1>
        <button className="btn btn-dark">
            <Link to="/create">
            Sign Up?
            </Link>
        </button>
      </div>
      <div>
      
            Username: <input type='text' name='uname'></input>
            Password: <input type='password' name='pwd'></input>
            <button type="button" onClick={Validate}>Login</button>
        
      </div>
      
      
      
    </section>
  );
};

export default LoginScreen;
