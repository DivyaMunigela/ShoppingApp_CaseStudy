import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import React from 'react'
import Products from "./Products";
import ViewCart from "./Components/ViewCart";
import { UserContext } from "./UserContext";


const LoginScreen = () => {
  
  const [data, setData] = useState([]);
  const prouctsPage = useNavigate();
  const {user,setUser}=useContext(UserContext);
  
  useEffect(() => { 
    axios
      .get("http://localhost:3005/users")
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
  
const setLoginName = () =>
{
  alert("123") 
  setUser(document.getElementById("fname").value)
  alert(user.username);
}

  function Validate()
{
  var uname=document.getElementById("fname").value;
  var pwd=document.getElementById("fpwd").value;
  if(uname==="" || pwd==="")
  {
     alert("Please enter username and password")
  }
  else
  {
  const userFound = data.map((user) =>
    user.username === uname & user.password === pwd? "Yes":"No"
  );
  
  if(userFound.includes("Yes"))
  {
      {/* <UserContext.Provider value={{user,setLoginName}}>
      <Products></Products>
      <ViewCart></ViewCart>
    </UserContext.Provider>  
      */}
      //setLoginName()
    
    prouctsPage("/products");
  }
  else
  alert("Incorrect username or password entered");
  }
}  
return (
    <section>
      <div>
        <h1>Welcome to TMart, Login to continue shopping</h1>
        <button className="btn btn-dark">
            <Link to="/SignUp">
            Sign Up?
            </Link>
        </button>
      </div>
      <div>
      
            Username: <input type='text' id ='fname' name='uname'></input>
            Password: <input type='password' id ='fpwd' name='pwd'></input>
            <button type="button" onClick={Validate}>Login</button>
        
      </div>
      
      
      
    </section>
  );
};

export default LoginScreen;
