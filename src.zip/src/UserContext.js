import { createContext } from "react";

export const userData={
    username:""
};
export const UserContext = createContext(userData);