import axios from "axios";
import { useState } from "react";

const ProductDetails = ({id,name,price}) => {
     const [itemSelected, setitemSelected] = useState({
    id: "",
    name: "",
    price: "",
    
  }); 
    const [items, setItems] = useState([]) 
    const handleUpdate = (id) => {
        alert("From Handle")
              
          axios
            .get(`http://localhost:3006/products/${id}`)
            .then((res) => {
                alert(res.data.name);
                
                setitemSelected({
          id: res.data.id,
          name: res.data.name,
          price: res.data.price
        });
        setItems([...items,itemSelected]);
               alert(items.length);
               
               //window.location.reload();

            })
            .catch((err) => console.log(err));
        };
      
    const handleDelete = (id) => {
    
    
      axios
        .get(`http://localhost:3006/products/${id}`)
        .then((res) => {
          // log the id here
          // window.location.reload();
          console.log(res);
        })
        .catch((err) => console.log(err));
    
    console.log(id);
  };

  return (
    <div>
      <div>
        <table>
            <tr>
          <td>{id}</td>
          <td>{name}</td>
          <td>{price}</td>
          
      

            <td>
          <button className="btn btn-dark" onClick={() => handleUpdate(id)}>Add to Cart</button>
        </td>
        <td>
            <button className="btn btn-dark" onClick={() => handleDelete(id)}>Remove From Cart</button>
            </td>
        </tr>
        </table>
       
      </div>
        
    </div>
  );
};


export default ProductDetails;
