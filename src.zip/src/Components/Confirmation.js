import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export default class Confirmation extends Component {
  render() {
    return (
      <div>
        <h1>Thank you for shopping with us, click to coninue shopping or Logout</h1>
        <Link to="/Products">
          <button className="btn btn-dark">Reorder</button>
        </Link>
        <Link to="/">
          <button className="btn btn-dark">Logout</button>
        </Link>

      </div>
    )
  }
}
