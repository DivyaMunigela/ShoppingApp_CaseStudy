import React from 'react';
import { Link, useLocation } from "react-router-dom"


const ViewCart = () => {
  
  
  //const location = useLocation()
  //const { from } = location.state
  //alert(from);
 // const [itemsList, setItemsList]=location.state?.cartItems
 //const [cartItems, setItemsList]=location.state
 //alert(cartItems.length);
// 
  
  return(
    <div>
    <h1>Items in Cart</h1>
    <table border="2">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            </tr>
        </thead>
        <tbody>      
    {/* {cartItems.map((product, index) => (
            <tr key={index}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>{product.price}</td>
             
            </tr>
          ))} */}
         </tbody>
</table>
<br/>  
     <Link to="/Confirmation">
          <button className="btn btn-dark">Place Order</button>
        </Link>
        <Link to="/Products">
          <button className="btn btn-dark">Update Cart</button>
        </Link>
        
    </div>
  );
}
export default ViewCart;