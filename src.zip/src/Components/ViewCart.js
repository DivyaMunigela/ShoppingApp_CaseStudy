import React from 'react';
import { useLocation } from "react-router-dom"


const ViewCart = (props) => {
  console.log(props)
  console.log(props.cartItems);
 // const location = useLocation()
  //const [itemsList, setItemsList]=location.state?.cartItems
// 
  
  return(
    <div>
    <h1>From Carts Page</h1>
    {/* <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            </tr>
        </thead>
        <tbody>      
    {location.state?.cartItems.map((product, index) => (
            <tr key={index}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>{product.price}</td>
             
            </tr>
          ))}
          </tbody>
</table> */}
    </div>
  );
}
export default ViewCart;