import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css"

const SignUp = () => {
  const [values, setValues] = useState({
    username: '',
    password : '',
    email: ''
  })

  const navigate = useNavigate();
  const handleSubmit = () => {
    if(values.email === "" || values.username === "" || values.email==="")
    {
      alert("Please input all fields")
    }
    else
    {
    axios
      .post("http://localhost:3005/users", values)
      .then((res) => {
        console.log(res)
        navigate("/");
      })
      .catch((err) => console.log(err));
    }
  }

  return (
    <div align="center">
      <div className="container">
        <h1>Sign Up To Order</h1>
        <form>
          <div>
          <label for="name">Name:</label>
            <input onChange={e => setValues({...values, username : e.target.value})} type="text" required  placeholder="Enter Name" name="name" className="w-64 h-7 rounded-xl px-2"/>
          </div>
          <div>
          <label for="password">Password:</label>
            <input class="form-control" onChange={e => setValues({...values, password : e.target.value})} type="email" required  placeholder="Enter Email" name="name" className="w-64 h-7 rounded-xl px-2"/>
          </div>
          <div>
          <label for="email">Email:</label>
            <input class="form-control" onChange={e => setValues({...values, email : e.target.value})} type="email" required  placeholder="Enter Email" name="name" className="w-64 h-7 rounded-xl px-2"/>
          </div>

        </form>
        <div>
          <button onClick={handleSubmit}>
            Submit
          </button> 
          <button>
            <Link to="/" style={{color:"white"}}>Cancel</Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
